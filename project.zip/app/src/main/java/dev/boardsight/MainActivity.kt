package dev.boardsight

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val reqCapture = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)
        root.setBackgroundColor(0xFF12151C.toInt())

        fun label(s: String, size: Float, color: Int): TextView {
            val t = TextView(this)
            t.text = s
            t.textSize = size
            t.setTextColor(color)
            t.setPadding(0, 0, 0, pad / 2)
            return t
        }

        root.addView(label("BoardSight", 28f, 0xFF7CFFB0.toInt()))
        root.addView(
            label(
                "1. Нажми «Запустить» и в окне записи экрана выбери ВЕСЬ ЭКРАН.\n" +
                    "2. Открой шахматное приложение. Поверх появится панель.\n" +
                    "3. Панель: «Доска» — тапни левый верхний и правый нижний углы доски; " +
                    "«Сетка» — проверить, что сетка легла ровно на клетки.\n" +
                    "4. Расставь начальную позицию и нажми «Старт» — приложение запомнит, как выглядят твои фигуры.\n" +
                    "5. «▶ Пуск». Стрелка покажет твой ход, когда очередь твоя.\n\n" +
                    "«Я: белые/чёрные» — каким цветом ты играешь (кто внизу доски). " +
                    "«Синхр» — прочитать позицию с экрана, если партия уже идёт.",
                15f, 0xFFDDE3EE.toInt()
            )
        )

        val start = Button(this)
        start.text = "Запустить"
        start.setOnClickListener { begin() }
        root.addView(start, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    @Suppress("DEPRECATION")
    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши показ поверх других окон", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, BoardService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        } else if (requestCode == reqCapture) {
            Toast.makeText(this, "Запись экрана не разрешена", Toast.LENGTH_LONG).show()
        }
    }
}
