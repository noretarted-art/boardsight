package dev.boardsight

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View

/** Full-screen transparent layer: draws the move arrow and (optionally) the board grid. */
class ArrowLayer(ctx: Context) : View(ctx) {
    var arrow: FloatArray? = null   // x1, y1, x2, y2 in screen pixels
    var label: String = ""
    var grid = false
    var bl = 0f
    var bt = 0f
    var bs = 0f

    private val loc = IntArray(2)
    private val green = 0xE62EE87A.toInt()

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = green
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val head = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = green
        style = Paint.Style.FILL
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = green
        style = Paint.Style.STROKE
    }
    private val gridP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xAAFF3B30.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 40f
        typeface = Typeface.DEFAULT_BOLD
    }
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xDD101016.toInt()
    }

    override fun onDraw(c: Canvas) {
        getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())

        if (grid && bs > 0f) {
            val cs = bs / 8f
            c.drawRect(bl, bt, bl + bs, bt + bs, gridP)
            for (i in 1 until 8) {
                c.drawLine(bl + i * cs, bt, bl + i * cs, bt + bs, gridP)
                c.drawLine(bl, bt + i * cs, bl + bs, bt + i * cs, gridP)
            }
        }

        val a = arrow
        if (a != null && bs > 0f) {
            val cs = bs / 8f
            val x1 = a[0]
            val y1 = a[1]
            val x2 = a[2]
            val y2 = a[3]
            val dx = x2 - x1
            val dy = y2 - y1
            val len = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (len > 1f) {
                val ux = dx / len
                val uy = dy / len
                val headLen = cs * 0.5f
                val headW = cs * 0.42f
                line.strokeWidth = cs * 0.16f
                ring.strokeWidth = cs * 0.06f
                c.drawCircle(x1, y1, cs * 0.42f, ring)

                val tipX = x2 - ux * cs * 0.08f
                val tipY = y2 - uy * cs * 0.08f
                val baseX = tipX - ux * headLen
                val baseY = tipY - uy * headLen
                c.drawLine(x1 + ux * cs * 0.3f, y1 + uy * cs * 0.3f, baseX, baseY, line)

                val path = Path()
                path.moveTo(tipX, tipY)
                path.lineTo(baseX - uy * headW, baseY + ux * headW)
                path.lineTo(baseX + uy * headW, baseY - ux * headW)
                path.close()
                c.drawPath(path, head)
            }
            if (label.isNotEmpty()) {
                val w = txt.measureText(label)
                val ty = if (bt > 90f) bt - 24f else bt + bs + 64f
                val r = RectF(bl, ty - 48f, bl + w + 32f, ty + 14f)
                c.drawRoundRect(r, 14f, 14f, bg)
                c.drawText(label, bl + 16f, ty, txt)
            }
        }
    }
}

/** Full-screen touch layer used once to tap two opposite corners of the board. */
class PickLayer(ctx: Context, private val onDone: (Float, Float, Float, Float) -> Unit) : View(ctx) {
    private val pts = ArrayList<FloatArray>()
    private val loc = IntArray(2)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFD60A.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 46f
        typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }

    override fun onDraw(c: Canvas) {
        getLocationOnScreen(loc)
        c.drawColor(0x33000000)
        val msg = if (pts.isEmpty()) "Тапни ЛЕВЫЙ ВЕРХНИЙ угол доски" else "Теперь ПРАВЫЙ НИЖНИЙ угол"
        c.drawText(msg, 40f, 140f, t)
        for (q in pts) {
            val x = q[0] - loc[0]
            val y = q[1] - loc[1]
            c.drawLine(x - 40, y, x + 40, y, p)
            c.drawLine(x, y - 40, x, y + 40, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            pts.add(floatArrayOf(e.rawX, e.rawY))
            invalidate()
            if (pts.size == 2) onDone(pts[0][0], pts[0][1], pts[1][0], pts[1][1])
        }
        return true
    }
}
