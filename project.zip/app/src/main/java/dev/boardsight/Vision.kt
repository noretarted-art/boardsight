package dev.boardsight

import android.graphics.Bitmap
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/** Silhouette mask + brightness of one board cell on a 16x16 grid. */
class Desc(val mask: BooleanArray, val lum: IntArray, val count: Int)

class Template(val ch: Char, val d: Desc)

object Vision {
    const val G = 16
    private const val MIN_PIX = 22   // fewer "piece pixels" than this = empty square
    private const val THRESH = 60    // colour distance from the square background

    fun cut(bmp: Bitmap, l: Int, t: Int, w: Int): IntArray? {
        if (w < 160 || l < 0 || t < 0 || l + w > bmp.width || t + w > bmp.height) return null
        val px = IntArray(w * w)
        bmp.getPixels(px, 0, w, l, t, w, w)
        return px
    }

    private fun median(a: IntArray, idx: List<Int>): Int {
        val v = IntArray(idx.size) { a[idx[it]] }
        v.sort()
        return v[v.size / 2]
    }

    /** row/col are screen rows/cols of the board region (row 0 = top). */
    fun describe(px: IntArray, w: Int, row: Int, col: Int): Desc {
        val cs = w / 8f
        val ox = col * cs + cs * 0.08f
        val oy = row * cs + cs * 0.08f
        val sub = cs * 0.84f / G
        val n = G * G
        val rr = IntArray(n)
        val gg = IntArray(n)
        val bb = IntArray(n)
        for (i in 0 until G) {
            for (j in 0 until G) {
                var sr = 0
                var sg = 0
                var sb = 0
                for (a in 0 until 3) {
                    for (c in 0 until 3) {
                        val x = (ox + (j + 0.25f + 0.25f * c) * sub).toInt().coerceIn(0, w - 1)
                        val y = (oy + (i + 0.25f + 0.25f * a) * sub).toInt().coerceIn(0, w - 1)
                        val p = px[y * w + x]
                        sr += (p shr 16) and 255
                        sg += (p shr 8) and 255
                        sb += p and 255
                    }
                }
                val k = i * G + j
                rr[k] = sr / 9
                gg[k] = sg / 9
                bb[k] = sb / 9
            }
        }
        // background colour of this particular square = median of its border sub-cells
        val ring = ArrayList<Int>()
        for (i in 0 until G) {
            for (j in 0 until G) {
                if (i < 2 || j < 2 || j >= G - 2) ring.add(i * G + j)
            }
        }
        val mr = median(rr, ring)
        val mg = median(gg, ring)
        val mb = median(bb, ring)

        val mask = BooleanArray(n)
        val lum = IntArray(n)
        var cnt = 0
        for (k in 0 until n) {
            val dd = Math.abs(rr[k] - mr) + Math.abs(gg[k] - mg) + Math.abs(bb[k] - mb)
            mask[k] = dd > THRESH
            if (mask[k]) cnt++
            lum[k] = (rr[k] * 77 + gg[k] * 151 + bb[k] * 28) shr 8
        }
        return Desc(mask, lum, cnt)
    }

    private fun dist(a: Desc, t: Desc): Float {
        var inter = 0
        var uni = 0
        var ld = 0
        for (k in 0 until G * G) {
            val ma = a.mask[k]
            val mt = t.mask[k]
            if (ma || mt) uni++
            if (ma && mt) {
                inter++
                ld += Math.abs(a.lum[k] - t.lum[k])
            }
        }
        if (uni == 0) return 9f
        val iou = inter.toFloat() / uni
        val lumd = if (inter > 0) ld.toFloat() / (inter * 255f) else 1f
        return (1f - iou) + 1.2f * lumd
    }

    private fun classify(d: Desc, tpl: List<Template>): Char {
        var bestCh = '.'
        var best = 1e9f
        for (t in tpl) {
            val s = dist(d, t.d)
            if (s < best) {
                best = s
                bestCh = t.ch
            }
        }
        return bestCh
    }

    private fun fileOf(col: Int, meWhite: Boolean) = if (meWhite) col else 7 - col
    private fun rankOf(row: Int, meWhite: Boolean) = if (meWhite) 7 - row else row

    /** Reads the whole board. Result is indexed rank*8+file regardless of board orientation. */
    fun read(bmp: Bitmap, l: Int, t: Int, w: Int, tpl: List<Template>, meWhite: Boolean): CharArray? {
        val px = cut(bmp, l, t, w) ?: return null
        val out = CharArray(64) { '.' }
        for (row in 0 until 8) {
            for (col in 0 until 8) {
                val d = describe(px, w, row, col)
                out[rankOf(row, meWhite) * 8 + fileOf(col, meWhite)] =
                    if (d.count < MIN_PIX) '.' else classify(d, tpl)
            }
        }
        return out
    }

    /** Learns piece templates from a screenshot of the starting position. */
    fun learnStart(bmp: Bitmap, l: Int, t: Int, w: Int, meWhite: Boolean): List<Template>? {
        val px = cut(bmp, l, t, w) ?: return null
        val back = "RNBQKBNR"
        val res = ArrayList<Template>()
        for (row in 0 until 8) {
            for (col in 0 until 8) {
                val file = fileOf(col, meWhite)
                val rank = rankOf(row, meWhite)
                val d = describe(px, w, row, col)
                val expected: Char = when (rank) {
                    0 -> back[file]
                    1 -> 'P'
                    6 -> 'p'
                    7 -> back[file].lowercaseChar()
                    else -> '.'
                }
                val occupied = d.count >= MIN_PIX
                if ((expected != '.') != occupied) return null
                if (expected != '.') res.add(Template(expected, d))
            }
        }
        return res
    }

    fun save(f: File, list: List<Template>) {
        DataOutputStream(BufferedOutputStream(FileOutputStream(f))).use { o ->
            o.writeInt(list.size)
            for (x in list) {
                o.writeChar(x.ch.code)
                for (k in 0 until G * G) {
                    o.writeBoolean(x.d.mask[k])
                    o.writeByte(x.d.lum[k])
                }
            }
        }
    }

    fun load(f: File): List<Template> {
        if (!f.exists()) return emptyList()
        return try {
            DataInputStream(BufferedInputStream(FileInputStream(f))).use { i ->
                val n = i.readInt()
                val res = ArrayList<Template>()
                for (q in 0 until n) {
                    val ch = i.readChar()
                    val mask = BooleanArray(G * G)
                    val lum = IntArray(G * G)
                    var cnt = 0
                    for (k in 0 until G * G) {
                        mask[k] = i.readBoolean()
                        lum[k] = i.readUnsignedByte()
                        if (mask[k]) cnt++
                    }
                    res.add(Template(ch, Desc(mask, lum, cnt)))
                }
                res
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
