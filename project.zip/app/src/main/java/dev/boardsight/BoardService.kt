package dev.boardsight

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class BoardService : Service() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var wt: HandlerThread
    private lateinit var worker: Handler
    private lateinit var prefs: SharedPreferences
    private lateinit var tplFile: File

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var latest: Bitmap? = null

    private lateinit var arrow: ArrowLayer
    private var pick: PickLayer? = null
    private lateinit var panel: LinearLayout
    private lateinit var panelLp: WindowManager.LayoutParams
    private lateinit var status: TextView
    private lateinit var runChip: TextView
    private lateinit var meChip: TextView
    private lateinit var depthChip: TextView

    private var engine: Uci? = null

    // board rectangle in screen pixels + settings
    @Volatile private var bl = 0
    @Volatile private var bt = 0
    @Volatile private var bsz = 0
    @Volatile private var meWhite = true
    @Volatile private var depthIdx = 1
    @Volatile private var running = false
    @Volatile private var hasArrow = false
    @Volatile private var gridOn = false
    @Volatile private var templates: List<Template> = emptyList()
    @Volatile private var lastFen: String? = null

    // state owned by the worker thread
    private var tracked: Position? = null
    private var stable: CharArray? = null
    private var fails = 0
    private var started = false

    private val depths = intArrayOf(10, 14, 18, 22)

    override fun onBind(intent: Intent?): IBinder? = null

    // ------------------------------------------------------------------ lifecycle

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (started || intent == null) return START_NOT_STICKY
        started = true
        goForeground()
        val data = readData(intent)
        val code = intent.getIntExtra("code", 0)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("bs", MODE_PRIVATE)
        tplFile = File(filesDir, "templates.bin")
        wt = HandlerThread("bs-worker")
        wt.start()
        worker = Handler(wt.looper)
        loadPrefs()
        try {
            startCapture(code, data)
        } catch (e: Exception) {
            Toast.makeText(this, "Захват экрана не запустился: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        buildUi()
        engine = Uci(applicationInfo.nativeLibraryDir, { s -> say(s) }, { fen, mv, label, fin -> onEngine(fen, mv, label, fin) })
        worker.post { engine?.start() }
        say(if (bsz >= 160) "Готово. Жми «Пуск»" else "Нажми «Доска» и тапни два угла")
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? {
        return if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra<Intent>("data")
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bs", "BoardSight", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bs")
            .setContentTitle("BoardSight работает")
            .setContentText("Управление — на плавающей панели")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                ui.post { stopSelf() }
            }
        }, ui)
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        val r = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        reader = r
        vdisplay = proj.createVirtualDisplay(
            "boardsight", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    override fun onDestroy() {
        running = false
        try { worker.removeCallbacksAndMessages(null) } catch (e: Exception) { }
        try { engine?.quit() } catch (e: Exception) { }
        val views = ArrayList<View>()
        if (::arrow.isInitialized) views.add(arrow)
        if (::panel.isInitialized) views.add(panel)
        pick?.let { views.add(it) }
        for (v in views) {
            try { wm.removeView(v) } catch (e: Exception) { }
        }
        try { vdisplay?.release() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { wt.quitSafely() } catch (e: Exception) { }
        super.onDestroy()
    }

    // ------------------------------------------------------------------ prefs

    private fun loadPrefs() {
        bl = prefs.getInt("bl", 0)
        bt = prefs.getInt("bt", 0)
        bsz = prefs.getInt("bsz", 0)
        meWhite = prefs.getBoolean("meWhite", true)
        depthIdx = prefs.getInt("depthIdx", 1).coerceIn(0, depths.size - 1)
        templates = Vision.load(tplFile)
    }

    private fun savePrefs() {
        prefs.edit()
            .putInt("bl", bl).putInt("bt", bt).putInt("bsz", bsz)
            .putBoolean("meWhite", meWhite).putInt("depthIdx", depthIdx)
            .apply()
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun say(s: String) {
        ui.post { if (::status.isInitialized) status.text = s }
    }

    private fun fullParams(touchable: Boolean): WindowManager.LayoutParams {
        var fl = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) fl = fl or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, fl, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        return lp
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 12f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(6), dp(8), dp(6), dp(8))
        val g = GradientDrawable()
        g.cornerRadius = dp(8).toFloat()
        g.setColor(0xFF2A2F3A.toInt())
        t.background = g
        t.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        t.layoutParams = lp
        return t
    }

    private fun row(vararg c: TextView): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (x in c) r.addView(x)
        return r
    }

    private fun buildUi() {
        arrow = ArrowLayer(this)
        wm.addView(arrow, fullParams(false))
        applyBoardToViews()

        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(6), dp(6), dp(6), dp(6))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(12).toFloat()
        bg.setColor(0xEE12151C.toInt())
        panel.background = bg

        val title = TextView(this)
        title.text = "≡ BoardSight  (тяни за заголовок)"
        title.setTextColor(0xFF7CFFB0.toInt())
        title.textSize = 12f
        title.setPadding(dp(6), dp(4), dp(6), dp(6))
        panel.addView(title)

        runChip = chip("▶ Пуск") { toggleRun() }
        meChip = chip(if (meWhite) "Я: белые" else "Я: чёрные") { toggleMe() }
        depthChip = chip("Глубина ${depths[depthIdx]}") { cycleDepth() }

        panel.addView(row(chip("Доска") { startPick() }, chip("Старт") { worker.post { calibrate() } }, chip("Синхр") { worker.post { syncNow() } }))
        panel.addView(row(runChip, meChip, chip("Сетка") { toggleGrid() }))
        panel.addView(row(depthChip, chip("Выход") { stopSelf() }))

        status = TextView(this)
        status.setTextColor(0xFFDDE3EE.toInt())
        status.textSize = 11f
        status.setPadding(dp(6), dp(4), dp(6), dp(2))
        status.text = "…"
        panel.addView(status)

        panelLp = WindowManager.LayoutParams(
            dp(270), ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        panelLp.gravity = Gravity.TOP or Gravity.START
        panelLp.x = dp(8)
        panelLp.y = dp(60)

        var sx = 0
        var sy = 0
        var dx = 0f
        var dy = 0f
        title.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = panelLp.x; sy = panelLp.y; dx = e.rawX; dy = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    panelLp.x = sx + (e.rawX - dx).toInt()
                    panelLp.y = sy + (e.rawY - dy).toInt()
                    try { wm.updateViewLayout(panel, panelLp) } catch (x: Exception) { }
                }
            }
            true
        }
        wm.addView(panel, panelLp)
    }

    private fun applyBoardToViews() {
        ui.post {
            arrow.bl = bl.toFloat()
            arrow.bt = bt.toFloat()
            arrow.bs = bsz.toFloat()
            arrow.grid = gridOn
            arrow.invalidate()
        }
    }

    private fun startPick() {
        ui.post {
            panel.visibility = View.GONE
            arrow.visibility = View.INVISIBLE
            val p = PickLayer(this) { x1, y1, x2, y2 ->
                ui.post {
                    pick?.let { try { wm.removeView(it) } catch (e: Exception) { } }
                    pick = null
                    panel.visibility = View.VISIBLE
                    arrow.visibility = View.VISIBLE
                    val l = Math.min(x1, x2).toInt()
                    val t = Math.min(y1, y2).toInt()
                    val s = ((Math.abs(x2 - x1) + Math.abs(y2 - y1)) / 2f).toInt()
                    worker.post { setBoard(l, t, s) }
                }
            }
            pick = p
            wm.addView(p, fullParams(true))
        }
    }

    private fun setBoard(l: Int, t: Int, s: Int) {
        if (s < 160) {
            say("Слишком маленькая доска. Попробуй ещё раз")
            return
        }
        bl = l; bt = t; bsz = s
        savePrefs()
        tracked = null; lastFen = null; stable = null
        gridOn = true
        applyBoardToViews()
        say("Доска задана. Если сетка легла ровно — расставь начальную позицию и жми «Старт»")
    }

    private fun toggleGrid() {
        gridOn = !gridOn
        applyBoardToViews()
    }

    private fun toggleMe() {
        meWhite = !meWhite
        savePrefs()
        ui.post { meChip.text = if (meWhite) "Я: белые" else "Я: чёрные" }
        worker.post {
            tracked = null; lastFen = null; stable = null
            engine?.cancel()
            clearArrow()
            say(if (meWhite) "Ты внизу играешь белыми" else "Ты внизу играешь чёрными")
        }
    }

    private fun cycleDepth() {
        depthIdx = (depthIdx + 1) % depths.size
        savePrefs()
        ui.post { depthChip.text = "Глубина ${depths[depthIdx]}" }
        worker.post { lastFen = null }
    }

    private fun toggleRun() {
        worker.post {
            if (!running) {
                if (bsz < 160 || templates.isEmpty()) {
                    say("Сначала «Доска» и «Старт»")
                    return@post
                }
                running = true
                ui.post { runChip.text = "■ Стоп" }
                say("Работаю…")
                worker.post(tick)
            } else {
                running = false
                engine?.cancel()
                clearArrow()
                ui.post { runChip.text = "▶ Пуск" }
                say("Остановлено")
            }
        }
    }

    // ------------------------------------------------------------------ capture

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return latest
        try {
            val plane = img.planes[0]
            val w = img.width
            val h = img.height
            val pad = plane.rowStride - plane.pixelStride * w
            val wide = Bitmap.createBitmap(w + pad / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
            wide.copyPixelsFromBuffer(plane.buffer)
            val bmp = if (pad == 0) wide else Bitmap.createBitmap(wide, 0, 0, w, h).also { wide.recycle() }
            latest?.recycle()
            latest = bmp
            return bmp
        } finally {
            img.close()
        }
    }

    /** Hides our own arrow/grid for a moment so they do not end up in the screenshot. */
    private fun captureClean(): Bitmap? {
        val hide = hasArrow || gridOn
        if (hide) {
            ui.post { arrow.visibility = View.INVISIBLE }
            Thread.sleep(180)
        }
        val b = try { grab() } catch (e: Exception) { null }
        if (hide) ui.post { arrow.visibility = View.VISIBLE }
        return b
    }

    // ------------------------------------------------------------------ logic (worker thread)

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                step()
            } catch (e: Throwable) {
                say("Ошибка: " + e.javaClass.simpleName + " " + e.message)
            }
            if (running) worker.postDelayed(this, 650)
        }
    }

    private fun calibrate() {
        if (bsz < 160) { say("Сначала задай доску"); return }
        val bmp = captureClean()
        if (bmp == null) { say("Кадра с экрана пока нет, попробуй ещё раз"); return }
        val t = Vision.learnStart(bmp, bl, bt, bsz, meWhite)
        if (t == null) {
            say("Не похоже на начальную позицию. Проверь сетку (кнопка «Сетка») и «Я: белые/чёрные»")
            return
        }
        templates = t
        Vision.save(tplFile, t)
        tracked = Position.start()
        lastFen = null; stable = null; fails = 0
        say("Запомнил ${t.size} фигур. Жми «Пуск»")
    }

    private fun syncNow() {
        if (templates.isEmpty()) { say("Сначала один раз «Старт» на начальной позиции"); return }
        val bmp = captureClean()
        if (bmp == null) { say("Кадра с экрана пока нет"); return }
        val obs = Vision.read(bmp, bl, bt, bsz, templates, meWhite)
        if (obs == null) { say("Доска выходит за экран"); return }
        adopt(obs)
    }

    private fun adopt(obs: CharArray) {
        val p = Position.fromBoard(obs, meWhite)
        if (p == null) {
            say("Не могу прочитать позицию (нужно по одному королю). Проверь сетку")
            return
        }
        tracked = p
        lastFen = null; stable = null; fails = 0
        ensureAnalysis(p)
    }

    private fun step() {
        val bmp = captureClean() ?: return
        val obs = Vision.read(bmp, bl, bt, bsz, templates, meWhite)
        if (obs == null) { say("Доска выходит за экран"); return }

        // act only on a picture that stayed the same for two ticks (skip piece animations)
        val prev = stable
        stable = obs
        if (prev == null || Chess.diff(prev, obs) != 0) return

        val cur = tracked
        if (cur == null) { adopt(obs); return }

        val start = Position.start()
        if (Chess.diff(obs, start.b) == 0 && Chess.diff(cur.b, start.b) != 0) {
            tracked = start; lastFen = null; fails = 0
            ensureAnalysis(start)
            return
        }

        val base = Chess.diff(cur.b, obs)
        if (base <= 1) {
            ensureAnalysis(cur)
            return
        }
        val next = Chess.match(cur, obs)
        if (next != null) {
            tracked = next
            fails = 0
            ensureAnalysis(next)
        } else if (base >= 4) {
            fails++
            say("Не понимаю, что изменилось ($fails/3)")
            if (fails >= 3) {
                fails = 0
                adopt(obs)
            }
        }
    }

    private fun ensureAnalysis(p: Position) {
        val e = engine
        if (p.white != meWhite) {
            if (lastFen != null) {
                e?.cancel()
                clearArrow()
                lastFen = null
            }
            say("Ход соперника…")
            return
        }
        val fen = p.fen()
        if (fen == lastFen) return
        lastFen = fen
        clearArrow()
        say("Думаю…")
        e?.go(fen, depths[depthIdx])
    }

    // ------------------------------------------------------------------ arrow

    private fun center(sq: Int): FloatArray {
        val cs = bsz / 8f
        val file = sq and 7
        val rank = sq shr 3
        val col = if (meWhite) file else 7 - file
        val row = if (meWhite) 7 - rank else rank
        return floatArrayOf(bl + (col + 0.5f) * cs, bt + (row + 0.5f) * cs)
    }

    private fun clearArrow() {
        hasArrow = false
        ui.post {
            arrow.arrow = null
            arrow.label = ""
            arrow.invalidate()
        }
    }

    private fun onEngine(fen: String, mv: String, label: String, fin: Boolean) {
        if (fen != lastFen || mv.length < 4 || !running) return
        val a = center(Chess.sqIndex(mv.substring(0, 2)))
        val b = center(Chess.sqIndex(mv.substring(2, 4)))
        val txt = "$mv  $label"
        hasArrow = true
        ui.post {
            arrow.arrow = floatArrayOf(a[0], a[1], b[0], b[1])
            arrow.label = txt
            arrow.invalidate()
        }
        if (fin) say("Ход: $txt")
    }
}
