package dev.boardsight

import java.io.BufferedWriter
import java.io.File
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/**
 * Talks to the bundled Stockfish binary (lib/arm64-v8a/libstockfish.so, a real executable).
 * onResult(fen, move, label, isFinal)
 */
class Uci(
    private val libDir: String,
    private val say: (String) -> Unit,
    private val onResult: (String, String, String, Boolean) -> Unit
) {
    private var proc: Process? = null
    private var out: BufferedWriter? = null
    private val lock = Any()
    private val pending = AtomicInteger(0)

    @Volatile private var active = false
    @Volatile private var ready = false
    @Volatile private var curFen = ""
    @Volatile private var lastLabel = ""
    private var queuedFen: String? = null
    private var queuedDepth = 14

    private val reDepth = Regex("depth (\\d+)")
    private val reCp = Regex("score cp (-?\\d+)")
    private val reMate = Regex("score mate (-?\\d+)")

    fun start() {
        val f = File(libDir, "libstockfish.so")
        if (!f.exists()) {
            say("Движок не найден: $libDir")
            return
        }
        try {
            val p = ProcessBuilder(f.absolutePath).redirectErrorStream(true).start()
            proc = p
            out = p.outputStream.bufferedWriter()
        } catch (e: Exception) {
            say("Движок не запустился: ${e.message}")
            return
        }
        thread(name = "uci-read", isDaemon = true) { readLoop() }
        raw("uci")
    }

    private fun raw(s: String) {
        try {
            synchronized(lock) {
                val o = out ?: return
                o.write(s)
                o.write("\n")
                o.flush()
            }
        } catch (e: Exception) {
            ready = false
        }
    }

    private fun readLoop() {
        try {
            val rd = proc!!.inputStream.bufferedReader()
            while (true) {
                val line = rd.readLine() ?: break
                handle(line)
            }
        } catch (e: Exception) {
            // process ended
        }
        ready = false
        say("Движок остановился")
    }

    private fun handle(l: String) {
        if (l == "uciok") {
            raw("setoption name Threads value 2")
            raw("setoption name Hash value 64")
            raw("isready")
        } else if (l == "readyok") {
            ready = true
            val q = queuedFen
            queuedFen = null
            if (q != null) go(q, queuedDepth) else say("Движок готов")
        } else if (l.startsWith("info")) {
            info(l)
        } else if (l.startsWith("bestmove")) {
            val p = pending.getAndDecrement()
            if (p == 1 && active) {
                val parts = l.split(" ")
                if (parts.size > 1 && parts[1] != "(none)") onResult(curFen, parts[1], lastLabel, true)
            }
        }
    }

    private fun info(l: String) {
        val i = l.indexOf(" pv ")
        if (i < 0) return
        val mv = l.substring(i + 4).trim().split(" ")[0]
        val d = reDepth.find(l)?.groupValues?.get(1)?.toInt() ?: 0
        var label = ""
        val cp = reCp.find(l)
        val mt = reMate.find(l)
        if (cp != null) {
            label = String.format(Locale.US, "%+.2f", cp.groupValues[1].toInt() / 100.0)
        } else if (mt != null) {
            label = "M" + mt.groupValues[1]
        }
        lastLabel = "$label d$d"
        if (active && pending.get() == 1 && d >= 6) onResult(curFen, mv, lastLabel, false)
    }

    fun go(fen: String, depth: Int) {
        synchronized(lock) {
            if (!ready) {
                queuedFen = fen
                queuedDepth = depth
                return
            }
            curFen = fen
            active = true
            pending.incrementAndGet()
        }
        raw("stop")
        raw("position fen $fen")
        raw("go depth $depth movetime 3500")
    }

    fun cancel() {
        active = false
        queuedFen = null
        raw("stop")
    }

    fun quit() {
        active = false
        raw("quit")
        try {
            proc?.destroy()
        } catch (e: Exception) {
        }
    }
}
