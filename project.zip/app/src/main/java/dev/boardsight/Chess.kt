package dev.boardsight

/** kind: 0 normal, 1 double pawn push, 2 en passant, 3 castling */
class Move(val from: Int, val to: Int, val promo: Char, val kind: Int) {
    fun uci(): String {
        val sb = StringBuilder()
        sb.append(Chess.sqName(from)).append(Chess.sqName(to))
        if (promo != ' ') sb.append(promo.lowercaseChar())
        return sb.toString()
    }
}

object Chess {
    val KN_R = intArrayOf(-2, -2, -1, -1, 1, 1, 2, 2)
    val KN_F = intArrayOf(-1, 1, -2, 2, -2, 2, -1, 1)

    // directions 0..3 diagonal, 4..7 straight
    val DR = intArrayOf(1, 1, -1, -1, 1, -1, 0, 0)
    val DF = intArrayOf(1, -1, 1, -1, 0, 0, 1, -1)

    fun sqName(s: Int): String = "" + ('a' + (s and 7)) + ('1' + (s shr 3))

    fun sqIndex(name: String): Int = (name[0] - 'a') + (name[1] - '1') * 8

    fun isWhite(c: Char): Boolean = c in 'A'..'Z'

    fun diff(a: CharArray, b: CharArray): Int {
        var n = 0
        for (i in 0 until 64) if (a[i] != b[i]) n++
        return n
    }

    /**
     * Finds the position reached from [cur] by one move (or two, if we missed one)
     * that best explains what is seen on the screen. Returns null if nothing explains it.
     */
    fun match(cur: Position, obs: CharArray): Position? {
        val base = diff(cur.b, obs)
        val l1 = cur.legalMoves()

        var best: Position? = null
        var bestD = 99
        for (m in l1) {
            val p = cur.make(m)
            val d = diff(p.b, obs)
            if (d < bestD) {
                bestD = d
                best = p
            }
        }
        if (bestD <= 2 && bestD < base) return best

        var best2: Position? = null
        var bestD2 = 99
        for (m in l1) {
            val p = cur.make(m)
            for (m2 in p.legalMoves()) {
                val q = p.make(m2)
                val d = diff(q.b, obs)
                if (d < bestD2) {
                    bestD2 = d
                    best2 = q
                }
            }
        }
        if (bestD2 <= 2 && bestD2 < base && bestD2 < bestD) return best2
        return null
    }
}

/** b[rank * 8 + file], rank 0 = white's first rank. Uppercase = white, '.' = empty. */
class Position(
    val b: CharArray,
    val white: Boolean,
    val castle: Int, // 1 = white O-O, 2 = white O-O-O, 4 = black O-O, 8 = black O-O-O
    val ep: Int,
    val half: Int,
    val full: Int
) {
    companion object {
        fun start(): Position {
            val bd = CharArray(64) { '.' }
            val back = "RNBQKBNR"
            for (f in 0 until 8) {
                bd[f] = back[f]
                bd[8 + f] = 'P'
                bd[48 + f] = 'p'
                bd[56 + f] = back[f].lowercaseChar()
            }
            return Position(bd, true, 15, -1, 0, 1)
        }

        /** Builds a position from a screen reading. Castling rights are dropped to be safe. */
        fun fromBoard(obs: CharArray, meWhite: Boolean): Position? {
            var wk = 0
            var bk = 0
            for (c in obs) {
                if (c == 'K') wk++
                if (c == 'k') bk++
            }
            if (wk != 1 || bk != 1) return null
            val p = Position(obs.copyOf(), meWhite, 0, -1, 0, 1)
            val oppInCheck = p.attacked(p.kingSq(!meWhite), meWhite)
            val meInCheck = p.attacked(p.kingSq(meWhite), !meWhite)
            if (oppInCheck && meInCheck) return null
            if (oppInCheck) return Position(obs.copyOf(), !meWhite, 0, -1, 0, 1)
            return p
        }
    }

    fun kingSq(w: Boolean): Int {
        val k = if (w) 'K' else 'k'
        for (i in 0 until 64) if (b[i] == k) return i
        return -1
    }

    fun attacked(sq: Int, byWhite: Boolean): Boolean {
        if (sq < 0) return false
        val r = sq shr 3
        val f = sq and 7

        val pawn = if (byWhite) 'P' else 'p'
        val pr = if (byWhite) r - 1 else r + 1
        if (pr in 0..7) {
            if (f > 0 && b[pr * 8 + f - 1] == pawn) return true
            if (f < 7 && b[pr * 8 + f + 1] == pawn) return true
        }

        val kn = if (byWhite) 'N' else 'n'
        for (i in 0 until 8) {
            val nr = r + Chess.KN_R[i]
            val nf = f + Chess.KN_F[i]
            if (nr in 0..7 && nf in 0..7 && b[nr * 8 + nf] == kn) return true
        }

        val kg = if (byWhite) 'K' else 'k'
        for (dr in -1..1) {
            for (df in -1..1) {
                if (dr == 0 && df == 0) continue
                val nr = r + dr
                val nf = f + df
                if (nr in 0..7 && nf in 0..7 && b[nr * 8 + nf] == kg) return true
            }
        }

        val bi = if (byWhite) 'B' else 'b'
        val ro = if (byWhite) 'R' else 'r'
        val qu = if (byWhite) 'Q' else 'q'
        for (d in 0 until 8) {
            var nr = r + Chess.DR[d]
            var nf = f + Chess.DF[d]
            while (nr in 0..7 && nf in 0..7) {
                val c = b[nr * 8 + nf]
                if (c != '.') {
                    if (c == qu) return true
                    if (d < 4 && c == bi) return true
                    if (d >= 4 && c == ro) return true
                    break
                }
                nr += Chess.DR[d]
                nf += Chess.DF[d]
            }
        }
        return false
    }

    fun legalMoves(): List<Move> {
        val res = ArrayList<Move>(40)
        for (m in pseudo()) {
            val p = make(m)
            val k = p.kingSq(white)
            if (k < 0 || !p.attacked(k, !white)) res.add(m)
        }
        return res
    }

    fun make(m: Move): Position {
        val nb = b.copyOf()
        val piece = nb[m.from]
        val captured = nb[m.to]
        nb[m.to] = piece
        nb[m.from] = '.'
        if (m.kind == 2) {
            val capSq = if (white) m.to - 8 else m.to + 8
            nb[capSq] = '.'
        }
        if (m.kind == 3) {
            when (m.to) {
                6 -> { nb[7] = '.'; nb[5] = 'R' }
                2 -> { nb[0] = '.'; nb[3] = 'R' }
                62 -> { nb[63] = '.'; nb[61] = 'r' }
                58 -> { nb[56] = '.'; nb[59] = 'r' }
            }
        }
        if (m.promo != ' ') {
            nb[m.to] = if (white) m.promo.uppercaseChar() else m.promo.lowercaseChar()
        }
        var c = castle
        if (piece == 'K') c = c and 3.inv()
        if (piece == 'k') c = c and 12.inv()
        if (m.from == 0 || m.to == 0) c = c and 2.inv()
        if (m.from == 7 || m.to == 7) c = c and 1.inv()
        if (m.from == 56 || m.to == 56) c = c and 8.inv()
        if (m.from == 63 || m.to == 63) c = c and 4.inv()
        val nep = if (m.kind == 1) (m.from + m.to) / 2 else -1
        val nh = if (piece.uppercaseChar() == 'P' || captured != '.') 0 else half + 1
        return Position(nb, !white, c, nep, nh, if (white) full else full + 1)
    }

    fun fen(): String {
        val sb = StringBuilder()
        for (r in 7 downTo 0) {
            var e = 0
            for (f in 0 until 8) {
                val c = b[r * 8 + f]
                if (c == '.') {
                    e++
                } else {
                    if (e > 0) {
                        sb.append(e)
                        e = 0
                    }
                    sb.append(c)
                }
            }
            if (e > 0) sb.append(e)
            if (r > 0) sb.append('/')
        }
        sb.append(if (white) " w " else " b ")
        var cs = ""
        if ((castle and 1) != 0) cs += "K"
        if ((castle and 2) != 0) cs += "Q"
        if ((castle and 4) != 0) cs += "k"
        if ((castle and 8) != 0) cs += "q"
        sb.append(if (cs.isEmpty()) "-" else cs)
        sb.append(' ')
        sb.append(if (ep >= 0) Chess.sqName(ep) else "-")
        sb.append(' ').append(half).append(' ').append(full)
        return sb.toString()
    }

    // ---------------------------------------------------------------- generation

    private fun pseudo(): ArrayList<Move> {
        val out = ArrayList<Move>(48)
        for (s in 0 until 64) {
            val c = b[s]
            if (c == '.' || Chess.isWhite(c) != white) continue
            val r = s shr 3
            val f = s and 7
            when (c.uppercaseChar()) {
                'P' -> pawn(out, s, r, f)
                'N' -> {
                    for (i in 0 until 8) {
                        val nr = r + Chess.KN_R[i]
                        val nf = f + Chess.KN_F[i]
                        if (nr in 0..7 && nf in 0..7) {
                            val t = nr * 8 + nf
                            if (b[t] == '.' || Chess.isWhite(b[t]) != white) out.add(Move(s, t, ' ', 0))
                        }
                    }
                }
                'B' -> slide(out, s, r, f, 0, 4)
                'R' -> slide(out, s, r, f, 4, 8)
                'Q' -> slide(out, s, r, f, 0, 8)
                'K' -> king(out, s, r, f)
            }
        }
        return out
    }

    private fun slide(out: ArrayList<Move>, s: Int, r: Int, f: Int, d0: Int, d1: Int) {
        for (d in d0 until d1) {
            var nr = r + Chess.DR[d]
            var nf = f + Chess.DF[d]
            while (nr in 0..7 && nf in 0..7) {
                val t = nr * 8 + nf
                val tc = b[t]
                if (tc == '.') {
                    out.add(Move(s, t, ' ', 0))
                } else {
                    if (Chess.isWhite(tc) != white) out.add(Move(s, t, ' ', 0))
                    break
                }
                nr += Chess.DR[d]
                nf += Chess.DF[d]
            }
        }
    }

    private fun addPawn(out: ArrayList<Move>, s: Int, t: Int, promo: Boolean) {
        if (promo) {
            for (p in "QRBN") out.add(Move(s, t, p, 0))
        } else {
            out.add(Move(s, t, ' ', 0))
        }
    }

    private fun pawn(out: ArrayList<Move>, s: Int, r: Int, f: Int) {
        val dir = if (white) 1 else -1
        val startR = if (white) 1 else 6
        val lastR = if (white) 7 else 0
        val r1 = r + dir
        if (r1 < 0 || r1 > 7) return
        val t = r1 * 8 + f
        if (b[t] == '.') {
            addPawn(out, s, t, r1 == lastR)
            if (r == startR) {
                val t2 = (r + 2 * dir) * 8 + f
                if (b[t2] == '.') out.add(Move(s, t2, ' ', 1))
            }
        }
        for (df in intArrayOf(-1, 1)) {
            val nf = f + df
            if (nf < 0 || nf > 7) continue
            val t3 = r1 * 8 + nf
            val tc = b[t3]
            if (tc != '.' && Chess.isWhite(tc) != white) {
                addPawn(out, s, t3, r1 == lastR)
            } else if (tc == '.' && t3 == ep) {
                out.add(Move(s, t3, ' ', 2))
            }
        }
    }

    private fun king(out: ArrayList<Move>, s: Int, r: Int, f: Int) {
        for (dr in -1..1) {
            for (df in -1..1) {
                if (dr == 0 && df == 0) continue
                val nr = r + dr
                val nf = f + df
                if (nr in 0..7 && nf in 0..7) {
                    val t = nr * 8 + nf
                    if (b[t] == '.' || Chess.isWhite(b[t]) != white) out.add(Move(s, t, ' ', 0))
                }
            }
        }
        if (white && s == 4) {
            if ((castle and 1) != 0 && b[7] == 'R' && b[5] == '.' && b[6] == '.' &&
                !attacked(4, false) && !attacked(5, false) && !attacked(6, false)
            ) out.add(Move(4, 6, ' ', 3))
            if ((castle and 2) != 0 && b[0] == 'R' && b[1] == '.' && b[2] == '.' && b[3] == '.' &&
                !attacked(4, false) && !attacked(3, false) && !attacked(2, false)
            ) out.add(Move(4, 2, ' ', 3))
        } else if (!white && s == 60) {
            if ((castle and 4) != 0 && b[63] == 'r' && b[61] == '.' && b[62] == '.' &&
                !attacked(60, true) && !attacked(61, true) && !attacked(62, true)
            ) out.add(Move(60, 62, ' ', 3))
            if ((castle and 8) != 0 && b[56] == 'r' && b[57] == '.' && b[58] == '.' && b[59] == '.' &&
                !attacked(60, true) && !attacked(59, true) && !attacked(58, true)
            ) out.add(Move(60, 58, ' ', 3))
        }
    }
}
