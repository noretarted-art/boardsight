plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.boardsight"
    compileSdk = 34

    defaultConfig {
        applicationId = "dev.boardsight"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "2.0"
        ndk {
            abiFilters.add("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        jniLibs {
            // Stockfish is an executable, so it must be extracted to nativeLibraryDir
            useLegacyPackaging = true
        }
    }
}
